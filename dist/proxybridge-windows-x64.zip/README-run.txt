ProxyBridge runtime (proxybridge-windows-x64)

Default upstream is SOCKS5 at 127.0.0.1:7898. That value is already in
proxybridge.toml. Start this program from the directory that contains the
toml file. CLI flags and PROXYBRIDGE_PROXY_* override it.

  proxybridge.exe run --mode socks
  proxybridge.exe config
  proxybridge.exe backends

Linux transparent TCP and UDP (root):
  sudo proxybridge.exe run --mode redirect

Windows transparent IPv4 (--mode windivert) needs WinDivert.dll and
WinDivert64.sys next to proxybridge.exe, and an elevated prompt.
macOS transparent capture needs a signed Network Extension, which is not
in this zip. Use --mode socks on macOS.
