ProxyBridge runtime (proxybridge-linux-x64)

Default upstream is SOCKS5 at 127.0.0.1:7898.
proxybridge.toml is the Proxifier profile (Direct by default, proxy for the
Dev/AI/Game domain lists, UDP left direct). The original .ppx and the same
toml are in profiles/. Start from this directory so ./proxybridge.toml loads.
CLI flags and PROXYBRIDGE_PROXY_* override the file.
You can also pass the original profile:
  ./proxybridge config --config profiles/user-proxifier-profile.ppx

  ./proxybridge run --mode socks
  ./proxybridge config
  ./proxybridge backends

Linux transparent TCP and UDP (root):
  sudo ./proxybridge run --mode redirect

Windows transparent IPv4 (--mode windivert) needs WinDivert.dll and
WinDivert64.sys next to proxybridge.exe, and an elevated prompt.
macOS transparent capture needs a signed Network Extension, which is not
in this zip. Use --mode socks on macOS.
